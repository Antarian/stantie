<?php
declare(strict_types=1);
namespace Antarian\Tests\Unit\Domain\TennisGame\Entity;

use Antarian\Domain\TennisGame\Entity\Player;
use Antarian\Domain\TennisGame\Entity\PlayerId;
use Antarian\Domain\TennisGame\Exception\InvalidPlayerPointsException;
use PHPUnit\Framework\TestCase;

class PlayerTest extends TestCase
{
    public function testPlayerInitialization(): void
    {
        $playerId = new PlayerId(1);
        $player = new Player($playerId, 'John', 'Doe', 0);

        $this->assertEquals($playerId, $player->getId());
        $this->assertEquals('John Doe', $player->getName());
        $this->assertEquals(0, $player->getPoints());
    }

    public function testAddPoint(): void
    {
        $playerId = new PlayerId(1);
        $player = new Player($playerId, 'John', 'Doe', 0);

        $player->addPoint();
        $this->assertEquals(1, $player->getPoints());
    }

    public function testPlayerPointsCannotBeNegative(): void
    {
        $this->expectException(InvalidPlayerPointsException::class);
        $this->expectExceptionMessage('Player points cannot be negative.');

        new Player(new PlayerId(1), 'John', 'Doe', -1);
    }
}
