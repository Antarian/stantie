<?php
declare(strict_types=1);
namespace Antarian\Tests\Unit\Domain\TennisGame\Entity;

use Antarian\Domain\TennisGame\Entity\Game;
use Antarian\Domain\TennisGame\Entity\GameId;
use Antarian\Domain\TennisGame\Entity\Player;
use Antarian\Domain\TennisGame\Entity\PlayerId;
use Antarian\Domain\TennisGame\Enum\Status;
use Antarian\Domain\TennisGame\Exception\GameNotInProgressException;
use Antarian\Domain\TennisGame\Exception\PlayerNotFoundInGameException;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class GameTest extends TestCase
{
    public function testGameInitialization(): void
    {
        $gameId = new GameId(1);
        $playerA = new Player(new PlayerId(1), 'John', 'Doe', 0);
        $playerB = new Player(new PlayerId(2), 'Jane', 'Smith', 0);

        $game = new Game($gameId, $playerA, $playerB);

        $this->assertEquals($gameId, $game->getId());
        $this->assertEquals('Love-Love', $game->getScore());
    }

    public function testPlayerWonAShot(): void
    {
        $gameId = new GameId(1);
        $playerA = new Player(new PlayerId(1), 'John', 'Doe', 0);
        $playerB = new Player(new PlayerId(2), 'Jane', 'Smith', 0);

        $game = new Game($gameId, $playerA, $playerB);

        $game->playerWonAShot($playerA->getId());
        $this->assertEquals('Fifteen-Love', $game->getScore());

        $game->playerWonAShot($playerB->getId());
        $this->assertEquals('Fifteen-Fifteen', $game->getScore());
    }

    public function testDeuce(): void
    {
        $gameId = new GameId(1);
        $playerA = new Player(new PlayerId(1), 'John', 'Doe', 3);
        $playerB = new Player(new PlayerId(2), 'Jane', 'Smith', 3);

        $game = new Game($gameId, $playerA, $playerB);

        $this->assertEquals('Deuce', $game->getScore());
    }

    #[DataProvider('advantageDataProvider')]
    public function testAdvantage(int $scoreA, int $scoreB, string $expectedScore): void
    {
        $gameId = new GameId(1);
        $playerA = new Player(new PlayerId(1), 'John', 'Doe', $scoreA);
        $playerB = new Player(new PlayerId(2), 'Jane', 'Smith', $scoreB);

        $game = new Game($gameId, $playerA, $playerB);

        $this->assertEquals($expectedScore, $game->getScore());
    }

    #[DataProvider('winDataProvider')]
    public function testWin(int $scoreA, int $scoreB, string $expectedScore): void
    {
        $gameId = new GameId(1);
        $playerA = new Player(new PlayerId(1), 'John', 'Doe', $scoreA);
        $playerB = new Player(new PlayerId(2), 'Jane', 'Smith', $scoreB);

        $game = new Game($gameId, $playerA, $playerB);

        $this->assertEquals($expectedScore, $game->getScore());
        $this->assertEquals(Status::Finished->value, $game->getStatus());
    }

    public static function advantageDataProvider(): array
    {
        return [
            'Advantage Player B' => [3, 4, 'Advantage Jane Smith'],
            'Advantage Player A' => [4, 3, 'Advantage John Doe'],
        ];
    }

    public static function winDataProvider(): array
    {
        return [
            'Player A wins 4-0' => [4, 0, 'Win for John Doe'],
            'Player A wins 4-2' => [4, 2, 'Win for John Doe'],
            'Player B wins 0-4' => [0, 4, 'Win for Jane Smith'],
            'Player B wins 2-4' => [2, 4, 'Win for Jane Smith'],
            'Player A wins 5-3' => [5, 3, 'Win for John Doe'],
            'Player B wins 3-5' => [3, 5, 'Win for Jane Smith'],
        ];
    }

    public function testPlayerWonAShotThrowsExceptionForIncorrectPlayerId(): void
    {
        $gameId = new GameId(1);
        $playerA = new Player(new PlayerId(1), 'John', 'Doe', 0);
        $playerB = new Player(new PlayerId(2), 'Jane', 'Smith', 0);
        $game = new Game($gameId, $playerA, $playerB);

        $this->expectException(PlayerNotFoundInGameException::class);
        $this->expectExceptionMessage('Game with id "1" does not have player with id "3".');

        $game->playerWonAShot(new PlayerId(3));
    }

    public function testPlayerWonAShotThrowsExceptionForFinishedGame(): void
    {
        $gameId = new GameId(1);
        $playerA = new Player(new PlayerId(1), 'John', 'Doe', 4);
        $playerB = new Player(new PlayerId(2), 'Jane', 'Smith', 0);
        $game = new Game($gameId, $playerA, $playerB, Status::Finished);

        $this->expectException(GameNotInProgressException::class);
        $this->expectExceptionMessage('Can\'t alter game which is not in progress');

        $game->playerWonAShot(new PlayerId(1));
    }
}
