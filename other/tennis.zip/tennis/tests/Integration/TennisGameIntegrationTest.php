<?php
declare(strict_types=1);

namespace Antarian\Tests\Integration;

use Antarian\App\Repository\InMemoryGameRepository;
use Antarian\App\Repository\InMemoryPlayerRepository;
use Antarian\Domain\TennisGame\Command\CreateGame;
use Antarian\Domain\TennisGame\Command\CreatePlayer;
use Antarian\Domain\TennisGame\Command\PlayerWonAShot;
use Antarian\Domain\TennisGame\CommandHandler\CreateGameHandler;
use Antarian\Domain\TennisGame\CommandHandler\CreatePlayerHandler;
use Antarian\Domain\TennisGame\CommandHandler\PlayerWonAShotHandler;
use Antarian\Domain\TennisGame\Factory\GameFactory;
use Antarian\Domain\TennisGame\Query\GetScore;
use Antarian\Domain\TennisGame\Query\GetStatus;
use Antarian\Domain\TennisGame\QueryHandler\GetScoreHandler;
use Antarian\Domain\TennisGame\QueryHandler\GetStatusHandler;
use PHPUnit\Framework\TestCase;

class TennisGameIntegrationTest extends TestCase
{
    private CreatePlayerHandler $createPlayerHandler;
    private CreateGameHandler $createGameHandler;
    private PlayerWonAShotHandler $playerWonAShotHandler;
    private GetScoreHandler $getScoreHandler;
    private GetStatusHandler $getStatusHandler;

    protected function setUp(): void
    {
        $playerRepository = new InMemoryPlayerRepository();
        $gameRepository = new InMemoryGameRepository();
        $gameFactory = new GameFactory();

        $this->createPlayerHandler = new CreatePlayerHandler($playerRepository);
        $this->createGameHandler = new CreateGameHandler($playerRepository, $gameRepository, $gameFactory);
        $this->playerWonAShotHandler = new PlayerWonAShotHandler($gameRepository);
        $this->getScoreHandler = new GetScoreHandler($gameRepository);
        $this->getStatusHandler = new GetStatusHandler($gameRepository);
    }

    public function testFullTennisGameSimulation(): void
    {
        // 1. Create Players
        $player1Id = ($this->createPlayerHandler)(new CreatePlayer('Novak', 'Djokovic'));
        $player2Id = ($this->createPlayerHandler)(new CreatePlayer('Carlos', 'Alcaraz'));

        // 2. Start Game
        $gameIdObj = ($this->createGameHandler)(new CreateGame($player1Id, $player2Id));
        $gameId = $gameIdObj->id;

        $this->assertEquals('Love-Love', ($this->getScoreHandler)(new GetScore($gameId)));
        $this->assertEquals('In progress', ($this->getStatusHandler)(new GetStatus($gameId)));

        // 3. Play Shots
        ($this->playerWonAShotHandler)(new PlayerWonAShot($player1Id, $gameId));
        $this->assertEquals('Fifteen-Love', ($this->getScoreHandler)(new GetScore($gameId)));

        ($this->playerWonAShotHandler)(new PlayerWonAShot($player2Id, $gameId));
        $this->assertEquals('Fifteen-Fifteen', ($this->getScoreHandler)(new GetScore($gameId)));

        ($this->playerWonAShotHandler)(new PlayerWonAShot($player1Id, $gameId));
        ($this->playerWonAShotHandler)(new PlayerWonAShot($player1Id, $gameId));
        $this->assertEquals('Forty-Fifteen', ($this->getScoreHandler)(new GetScore($gameId)));

        // Finish Game
        ($this->playerWonAShotHandler)(new PlayerWonAShot($player1Id, $gameId));
        $this->assertEquals('Win for Novak Djokovic', ($this->getScoreHandler)(new GetScore($gameId)));
        $this->assertEquals('Finished', ($this->getStatusHandler)(new GetStatus($gameId)));
    }

    public function testDeuceAndAdvantageSimulation(): void
    {
        $player1Id = ($this->createPlayerHandler)(new CreatePlayer('Player', 'A'));
        $player2Id = ($this->createPlayerHandler)(new CreatePlayer('Player', 'B'));
        $gameIdObj = ($this->createGameHandler)(new CreateGame($player1Id, $player2Id));
        $gameId = $gameIdObj->id;

        // Reach 40-40
        for ($i = 0; $i < 3; $i++) {
            ($this->playerWonAShotHandler)(new PlayerWonAShot($player1Id, $gameId));
            ($this->playerWonAShotHandler)(new PlayerWonAShot($player2Id, $gameId));
        }
        $this->assertEquals('Deuce', ($this->getScoreHandler)(new GetScore($gameId)));

        // Advantage Player A
        ($this->playerWonAShotHandler)(new PlayerWonAShot($player1Id, $gameId));
        $this->assertEquals('Advantage Player A', ($this->getScoreHandler)(new GetScore($gameId)));

        // Back to Deuce
        ($this->playerWonAShotHandler)(new PlayerWonAShot($player2Id, $gameId));
        $this->assertEquals('Deuce', ($this->getScoreHandler)(new GetScore($gameId)));

        // Advantage Player B
        ($this->playerWonAShotHandler)(new PlayerWonAShot($player2Id, $gameId));
        $this->assertEquals('Advantage Player B', ($this->getScoreHandler)(new GetScore($gameId)));

        // Win for Player B
        ($this->playerWonAShotHandler)(new PlayerWonAShot($player2Id, $gameId));
        $this->assertEquals('Win for Player B', ($this->getScoreHandler)(new GetScore($gameId)));
        $this->assertEquals('Finished', ($this->getStatusHandler)(new GetStatus($gameId)));
    }
}
