<?php
declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

use Antarian\App\Repository\InMemoryGameRepository;
use Antarian\App\Repository\InMemoryPlayerRepository;
use Antarian\Domain\TennisGame\Command\CreateGame;
use Antarian\Domain\TennisGame\Command\CreatePlayer;
use Antarian\Domain\TennisGame\Command\PlayerWonAShot;
use Antarian\Domain\TennisGame\CommandHandler\CreateGameHandler;
use Antarian\Domain\TennisGame\CommandHandler\CreatePlayerHandler;
use Antarian\Domain\TennisGame\CommandHandler\PlayerWonAShotHandler;
use Antarian\Domain\TennisGame\Factory\GameFactory;
use Antarian\Domain\TennisGame\Query\GetScore;
use Antarian\Domain\TennisGame\Query\GetStatus;
use Antarian\Domain\TennisGame\QueryHandler\GetScoreHandler;
use Antarian\Domain\TennisGame\QueryHandler\GetStatusHandler;

// --- Infrastructure: In-Memory Repositories ---

$playerRepository = new InMemoryPlayerRepository();
$gameRepository = new InMemoryGameRepository();

// --- Infrastructure: Game Factory ---

$gameFactory = new GameFactory();

// --- Wiring Handlers ---

$createPlayerHandler = new CreatePlayerHandler($playerRepository);
$createGameHandler = new CreateGameHandler($playerRepository, $gameRepository, $gameFactory);
$playerWonAShotHandler = new PlayerWonAShotHandler($gameRepository);
$getScoreHandler = new GetScoreHandler($gameRepository);
$getStatusHandler = new GetStatusHandler($gameRepository);

// --- Simulation ---

echo "--- Setting up Game ---\n";

// 1. Create Players
$player1Id = $createPlayerHandler(new CreatePlayer('Novak', 'Djokovic'));
$player2Id = $createPlayerHandler(new CreatePlayer('Carlos', 'Alcaraz'));

// 2. Start Game
$gameIdObj = $createGameHandler(new CreateGame($player1Id, $player2Id));
$gameId = $gameIdObj->id;
echo "Repository: Game started (ID: $gameId).\n";

echo "\n--- Simulation Start ---\n";

// 3. Play Shots
echo "Action: Novak wins a point.\n";
$playerWonAShotHandler(new PlayerWonAShot($player1Id, $gameId));
echo "Score: " . $getScoreHandler(new GetScore($gameId)) . "\n";

echo "Action: Carlos wins a point.\n";
$playerWonAShotHandler(new PlayerWonAShot($player2Id, $gameId));
echo "Score: " . $getScoreHandler(new GetScore($gameId)) . "\n";

echo "Action: Novak wins a point.\n";
$playerWonAShotHandler(new PlayerWonAShot($player1Id, $gameId));
echo "Score: " . $getScoreHandler(new GetScore($gameId)) . "\n";

echo "\n--- Game Status ---\n";
echo "Status: " . $getStatusHandler(new GetStatus($gameId)) . "\n";

echo "\n--- Simulation Continues ---\n";

echo "Action: Novak wins a point.\n";
$playerWonAShotHandler(new PlayerWonAShot($player1Id, $gameId));
echo "Score: " . $getScoreHandler(new GetScore($gameId)) . "\n";

echo "Action: Carlos wins a point.\n";
$playerWonAShotHandler(new PlayerWonAShot($player2Id, $gameId));
echo "Score: " . $getScoreHandler(new GetScore($gameId)) . "\n";

echo "Action: Novak wins a point.\n";
$playerWonAShotHandler(new PlayerWonAShot($player1Id, $gameId));
echo "Score: " . $getScoreHandler(new GetScore($gameId)) . "\n";

echo "\n--- Game Status ---\n";
echo "Status: " . $getStatusHandler(new GetStatus($gameId)) . "\n";
