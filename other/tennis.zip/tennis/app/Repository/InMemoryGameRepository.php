<?php
declare(strict_types=1);
namespace Antarian\App\Repository;

use Antarian\Domain\TennisGame\Entity\Entity;
use Antarian\Domain\TennisGame\Entity\EntityId;
use Antarian\Domain\TennisGame\Entity\Game;
use Antarian\Domain\TennisGame\Entity\GameId;
use Antarian\Domain\TennisGame\Repository\GameRepository;
use ReflectionException;

class InMemoryGameRepository implements GameRepository
{
    private array $games = [];

    public function load(GameId|EntityId $id): Game
    {
        if (!isset($this->games[$id->id])) {
            throw new \RuntimeException(sprintf("Game with ID %d not found.", $id->id));
        }
        return $this->games[$id->id];
    }

    public function store(Game|Entity $entity): GameId
    {
        $reflection = new \ReflectionClass($entity);
        try {
            $property = $reflection->getProperty('id');
        } catch (ReflectionException $e) {
            foreach ($reflection->getProperties() as $prop) {
                if ($prop->getType() && $prop->getType()->getName() === GameId::class) {
                    $property = $prop;
                    break;
                }
            }
        }

        $gameId = $property->getValue($entity);

        if ($gameId->id === null) {
            $newId = count($this->games) + 1;
            $gameId = new GameId($newId);
            $property->setValue($entity, $gameId);
        }

        $this->games[$gameId->id] = $entity;
        return $gameId;
    }
}