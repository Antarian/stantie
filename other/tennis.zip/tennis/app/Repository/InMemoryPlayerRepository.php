<?php
declare(strict_types=1);
namespace Antarian\App\Repository;

use Antarian\Domain\TennisGame\Entity\Entity;
use Antarian\Domain\TennisGame\Entity\EntityId;
use Antarian\Domain\TennisGame\Entity\Player;
use Antarian\Domain\TennisGame\Entity\PlayerId;
use Antarian\Domain\TennisGame\Repository\PlayerRepository;
use ReflectionException;

class InMemoryPlayerRepository implements PlayerRepository
{
    private array $players = [];

    public function load(PlayerId|EntityId $id): Player
    {
        if (!isset($this->players[$id->id])) {
            throw new \RuntimeException(sprintf("Player with ID %d not found.", $id->id));
        }
        return $this->players[$id->id];
    }

    public function store(Player|Entity $entity): PlayerId
    {
        $reflection = new \ReflectionClass($entity);
        try {
            $property = $reflection->getProperty('id');
        } catch (ReflectionException $e) {
            foreach ($reflection->getProperties() as $prop) {
                if ($prop->getType() && $prop->getType()->getName() === PlayerId::class) {
                    $property = $prop;
                    break;
                }
            }
        }

        $playerId = $property->getValue($entity);

        if ($playerId->id === null) {
            $newId = count($this->players) + 1;
            $playerId = new PlayerId($newId);
            $property->setValue($entity, $playerId);
        }

        $this->players[$playerId->id] = $entity;

        return $playerId;
    }
}