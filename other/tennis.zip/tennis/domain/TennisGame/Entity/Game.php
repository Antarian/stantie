<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Entity;

use Antarian\Domain\TennisGame\Enum\Score;
use Antarian\Domain\TennisGame\Enum\Status;
use Antarian\Domain\TennisGame\Exception\GameNotInProgressException;
use Antarian\Domain\TennisGame\Exception\PlayerNotFoundInGameException;

final class Game implements Entity
{
    public function __construct(
        private GameId $id,
        private Player $playerA,
        private Player $playerB,
        private Status $status = Status::InProgress,
    ) {
    }

    public function getId(): GameId
    {
        return $this->id;
    }

    public function playerWonAShot(PlayerId $playerId): void
    {
        if (Status::InProgress !== $this->status) {
            throw new GameNotInProgressException('Can\'t alter game which is not in progress');
        }

        if ($this->playerA->getId()->id !== $playerId->id && $this->playerB->getId()->id !== $playerId->id) {
            throw new PlayerNotFoundInGameException(sprintf('Game with id "%s" does not have player with id "%s".', $this->id->id, $playerId->id));
        }

        if ($this->playerA->getId()->equal($playerId)) {
            $this->playerA->addPoint();
        }

        if ($this->playerB->getId()->equal($playerId)) {
            $this->playerB->addPoint();
        }

        $this->getScore();
    }

    public function getScore(): string
    {
        $playerAPoints = $this->playerA->getPoints();
        $playerBPoints = $this->playerB->getPoints();

        if ($playerAPoints >= 3 && $playerBPoints >= 3) {
            if ($playerAPoints === $playerBPoints) {
                return "Deuce";
            }
            if (abs($playerAPoints - $playerBPoints) === 1) {
                return "Advantage " . ($playerAPoints > $playerBPoints ? $this->playerA->getName() : $this->playerB->getName());
            }
            $this->status = Status::Finished;
            return "Win for " . ($playerAPoints > $playerBPoints ? $this->playerA->getName() : $this->playerB->getName());
        }

        if ($playerAPoints >= 4 || $playerBPoints >= 4) {
            $this->status = Status::Finished;
            return "Win for " . ($playerAPoints > $playerBPoints ? $this->playerA->getName() : $this->playerB->getName());
        }

        return Score::from($playerAPoints)->name . "-" . Score::from($playerBPoints)->name;
    }

    public function getStatus(): string
    {
        return $this->status->value;
    }
}