<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Entity;

use Antarian\Domain\TennisGame\Exception\InvalidPlayerPointsException;

final class Player implements Entity
{
    public function __construct(
        private PlayerId $id,
        private string $firstName,
        private string $lastName,
        private int $points,
    ) {
        if ($this->points < 0) {
            throw new InvalidPlayerPointsException('Player points cannot be negative.');
        }
    }

    public function getId(): PlayerId
    {
        return $this->id;
    }

    public function addPoint(): void
    {
        $this->points++;
    }

    public function getPoints(): int
    {
        return $this->points;
    }

    public function getName(): string
    {
        return $this->firstName . ' ' . $this->lastName;
    }
}
