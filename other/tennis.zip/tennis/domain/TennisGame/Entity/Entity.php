<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Entity;

interface Entity
{
    public function getId(): EntityId;
}
