<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Entity;

/**
 * @template T of EntityId
 */
interface EntityId
{
    /**
     * @param T $id
     */
    public function equal(EntityId $id): bool;
}
