<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Entity;

/**
 * @implements EntityId<GameId>
 */
final class GameId implements EntityId
{
    public function __construct(
        public ?int $id,
    ) {
    }

    public function equal(GameId|EntityId $id): bool
    {
        return $id instanceof GameId && $this->id === $id->id;
    }
}