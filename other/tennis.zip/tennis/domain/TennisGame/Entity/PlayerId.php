<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Entity;

/**
 * @implements EntityId<PlayerId>
 */
final class PlayerId implements EntityId
{
    public function __construct(
        public ?int $id,
    ) {
    }

    public function equal(PlayerId|EntityId $id): bool
    {
        return $id instanceof PlayerId && $this->id === $id->id;
    }
}