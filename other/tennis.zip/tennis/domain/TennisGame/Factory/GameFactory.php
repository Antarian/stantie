<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Factory;

use Antarian\Domain\TennisGame\Entity\Game;
use Antarian\Domain\TennisGame\Entity\GameId;
use Antarian\Domain\TennisGame\Entity\Player;

class GameFactory
{

    public function createGame(Player $playerA, Player $playerB): Game
    {
        return new Game(
            new GameId(null),
            $playerA,
            $playerB
        );
    }
}