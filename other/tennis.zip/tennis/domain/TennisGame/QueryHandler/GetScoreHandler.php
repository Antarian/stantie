<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\QueryHandler;

use Antarian\Domain\TennisGame\Entity\GameId;
use Antarian\Domain\TennisGame\Query\GetScore;
use Antarian\Domain\TennisGame\Repository\GameRepository;

class GetScoreHandler
{
    public function __construct(
        private GameRepository $gameRepository,
    ) {
    }

    public function __invoke(GetScore $query): string
    {
        $game = $this->gameRepository->load(new GameId($query->gameId));

        return $game->getScore();
    }
}