<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\CommandHandler;

use Antarian\Domain\TennisGame\Command\CreateGame;
use Antarian\Domain\TennisGame\Entity\GameId;
use Antarian\Domain\TennisGame\Entity\PlayerId;
use Antarian\Domain\TennisGame\Factory\GameFactory;
use Antarian\Domain\TennisGame\Repository\GameRepository;
use Antarian\Domain\TennisGame\Repository\PlayerRepository;

class CreateGameHandler
{
    public function __construct(
        private PlayerRepository $playerRepository,
        private GameRepository $gameRepository,
        private GameFactory $gameFactory,
    ) {
    }

    public function __invoke(CreateGame $command): GameId
    {
        $playerA = $this->playerRepository->load(new PlayerId($command->playerA));
        $playerB = $this->playerRepository->load(new PlayerId($command->playerB));
        $game = $this->gameFactory->createGame($playerA, $playerB);
        $this->gameRepository->store($game);

        return $game->getId();
    }
}