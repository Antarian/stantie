<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\CommandHandler;

use Antarian\Domain\TennisGame\Command\PlayerWonAShot;
use Antarian\Domain\TennisGame\Entity\GameId;
use Antarian\Domain\TennisGame\Entity\PlayerId;
use Antarian\Domain\TennisGame\Repository\GameRepository;

class PlayerWonAShotHandler
{
    public function __construct(
        private GameRepository $gameRepository,
    ) {
    }

    public function __invoke(PlayerWonAShot $command): void
    {
        $game = $this->gameRepository->load(new GameId($command->gameId));

        $game->playerWonAShot(new PlayerId($command->playerId));

        $this->gameRepository->store($game);
    }
}