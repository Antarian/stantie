<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\CommandHandler;

use Antarian\Domain\TennisGame\Command\CreatePlayer;
use Antarian\Domain\TennisGame\Entity\Player;
use Antarian\Domain\TennisGame\Entity\PlayerId;
use Antarian\Domain\TennisGame\Repository\PlayerRepository;

class CreatePlayerHandler
{
    public function __construct(
        private PlayerRepository $playerRepository,
    ) {
    }

    public function __invoke(CreatePlayer $command): int
    {
        $player = new Player(
            new PlayerId(null),
            $command->firstName,
            $command->lastName,
            0
        );

        return $this->playerRepository->store($player)->id;
    }
}