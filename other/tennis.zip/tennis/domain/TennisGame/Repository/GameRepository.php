<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Repository;

use Antarian\Domain\TennisGame\Entity\Entity;
use Antarian\Domain\TennisGame\Entity\EntityId;
use Antarian\Domain\TennisGame\Entity\Game;
use Antarian\Domain\TennisGame\Entity\GameId;

/**
 * @extends Repository<Game, GameId>
 */
interface GameRepository extends Repository
{
    public function load(GameId|EntityId $id): Game;
    public function store(Game|Entity $entity): GameId;
}