<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Repository;

use Antarian\Domain\TennisGame\Entity\Entity;
use Antarian\Domain\TennisGame\Entity\EntityId;
use Antarian\Domain\TennisGame\Entity\Player;
use Antarian\Domain\TennisGame\Entity\PlayerId;

/**
 * @extends Repository<Player, PlayerId>
 */
interface PlayerRepository extends Repository
{
    public function load(PlayerId|EntityId $id): Player;
    public function store(Player|Entity $entity): PlayerId;
}