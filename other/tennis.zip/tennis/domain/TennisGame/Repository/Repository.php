<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Repository;

use Antarian\Domain\TennisGame\Entity\Entity;
use Antarian\Domain\TennisGame\Entity\EntityId;

/**
 * @template T of Entity
 * @template I of EntityId
 */
interface Repository
{
    /**
     * @param I $id
     * @return T
     */
    public function load(EntityId $id): Entity;

    /**
     * @param T $entity
     * @return I
     */
    public function store(Entity $entity): EntityId;
}