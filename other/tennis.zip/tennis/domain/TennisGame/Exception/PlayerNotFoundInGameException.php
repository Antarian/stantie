<?php
declare(strict_types=1);

namespace Antarian\Domain\TennisGame\Exception;

use Exception;

class PlayerNotFoundInGameException extends Exception
{
}
