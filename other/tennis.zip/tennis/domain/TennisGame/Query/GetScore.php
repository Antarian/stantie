<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Query;

final readonly class GetScore
{
    public function __construct(
        public int $gameId,
    ) {
    }
}