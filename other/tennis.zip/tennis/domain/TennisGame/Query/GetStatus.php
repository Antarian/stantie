<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Query;

final readonly class GetStatus
{
    public function __construct(
        public int $gameId
    ) {
    }
}