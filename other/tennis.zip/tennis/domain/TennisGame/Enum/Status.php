<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Enum;

enum Status: string
{
    case Finished = 'Finished';
    case InProgress = 'In progress';
}
