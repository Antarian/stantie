<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Enum;

enum Score: int
{
    case Love = 0;
    case Fifteen = 1;
    case Thirty = 2;
    case Forty = 3;
}
