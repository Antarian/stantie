<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Command;

final readonly class CreatePlayer
{
    public function __construct(
        public string $firstName,
        public string $lastName,
    ) {
    }
}