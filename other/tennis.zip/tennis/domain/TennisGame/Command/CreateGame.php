<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Command;

final readonly class CreateGame
{
    public function __construct(
        public int $playerA,
        public int $playerB,
    ) {
    }
}