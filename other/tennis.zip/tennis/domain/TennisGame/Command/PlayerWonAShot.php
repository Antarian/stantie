<?php
declare(strict_types=1);
namespace Antarian\Domain\TennisGame\Command;

final readonly class PlayerWonAShot
{
    public function __construct(
        public int $playerId,
        public int $gameId,
    ) {
    }
}