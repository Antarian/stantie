
I have used Model Driven Design to implement tennis game based on parameters for the exercise.

This is basic implementation only, not containing any CQRS or ES (events). Object Game is acting as an aggregate root here, and Player is entity containing a score of the player for given game. Score can be extracted to Game as value object, but I think it is not necessary here.

Id classes for entities. I am used to this style, as it is allowing easier change from int to uuid style for entity id. In the example id is coming from repository. If uuid is used, it can come from fronted api, be created by factory or same as now provided by repository.

## Local PHP install

Next commands are expecting php to be installed locally or executed inside a docker machine.
To install the project, you need to run composer
```shell
composer install
```

To run project test and setup example for plain PHP which is in index.php file.
```shell
php ./app/index.php
```

To run tests
```shell
php ./vendor/bin/phpunit
```

## Docker

To run the project inside a docker machine, you can use the following commands:

```shell
cd .docker
docker compose up -d --build
docker compose exec pl-tennis-game composer install
docker compose exec pl-tennis-game php ./app/index.php
docker compose exec pl-tennis-game php ./vendor/bin/phpunit
```
