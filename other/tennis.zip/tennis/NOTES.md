
### Points table
| Status             | Player A points | Player B points |
|--------------------|-----------------|-----------------|
| Deuce              | 3               | 3               |
| Player A advantage | 4               | 3               |
| Player A won       | 4               | 2               |
| Player A won       | 5               | 3               |
| Player B advantage | 3               | 4               |
| Player B won       | 2               | 4               |
| Player B won       | 3               | 5               |
| Reset to Deuce*    | 4               | 4               |

0 - Love
1 - 15
2 - 30
3 - 40
4 - win (Game)

*Reset to Deuce is not real status, but status when reset needs to happen

### Relations

| tennis_game |
|-------------|
| id          |
| status      |

| scores    |
|-----------|
| id        |
| game_id   |
| player_id |
| points    |

| players |
|---------|
| id      |

```
class Game
__constructor(int $id, Player $playerA, Player $playerB, Status $status = 'inProgress')

playerWonAShot(Player $player)
 - addPoint
    - if inProgress
 - checkScore(Player $scoringPlayer, Player $opponent)
    - resetToDeuce? (both players 4 points)
    - advantage? (reached 4 points, opponent has 3 points)
    - won? (reached at least 4 points, other player has 2 points less, e.g. 2, 1 or 0)
        - updateStatus(finished)
    - deuce? (both players has 3 points)

updateStatus()
    - inProgress, finished

class Player
__constructor(int $id, int $points)

addPoint()
```
